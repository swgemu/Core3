//
//CoreSocket.cpp
//(C) SWGEmu 2006
//
//Main Socket Operations such as Starting, Sending, and Recv'ing.
//

#include <time.h>

#include "CoreServer.h"
#include "packetfunctions.h"
#include "pHandler.h"
#include <stdio.h>

cSpawn spawny;

client_object oclient;


ServerSocket::ServerSocket( )
{
    Socket  = INVALID_SOCKET;
    Active  = false;
}


ServerSocket::~ServerSocket( )
{

}


#ifdef WIN32
//Server Init Function. Init winsock on windows. Called only on windows.
bool ServerSocket::InitSocket (void) //Init socket, WSA Startup (windows only)
{
    WSADATA wsa;
    memset(&wsa, 0x0, sizeof(WSADATA));
    if(WSAStartup(MAKEWORD(2,0),&wsa) != 0x0)
    {
        Log( LOG_PRINT | LOG_CORE_SERVER, NULL, "WSAStartup failed!");
    }
}
#endif





//The StartServer Function
//Used for Starting the server (Binding, Listening, etc.)
bool ServerSocket::StartServer(unsigned short Port, bool Proto)
{

    if(Proto == 0)
    { //Sets the socket protocol as UDP
        Socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    }
    else
    { //else, sets the socket protocol as TCP
        Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    }
    if ( Socket==INVALID_SOCKET ) //If theres a problem :(  then report it :)
    {
        return false;
    }
    mode = 0; //0 = Blocking, 1 = NonBlocking
    //Set the ioctl mode.
#ifdef WIN32

    ret = ioctlsocket(Socket, FIONBIO, &mode );
#else

    ret = ioctl(Socket, FIONBIO, &mode );
#endif

    if(ret < 0)
    { //If theres a problem, report it and then close the server.
        CloseSocket();
        Socket = INVALID_SOCKET;
        Log( LOG_PRINT | LOG_CORE_SERVER, NULL, "Ioctl FIBIO (Blocking Mode) failed!");
    }
    memset(&ain, 0, sizeof(ain)); // Clear struct
    ain.sin_family = AF_INET;
    ain.sin_addr.s_addr = INADDR_ANY;
    ain.sin_port = htons(Port); //sets port

    // Bind the server socket
    if (bind(Socket, (struct sockaddr *)&ain, sizeof(ain)) < 0)
    {
        CloseSocket();
        Socket = INVALID_SOCKET;
        Log( LOG_PRINT | LOG_CORE_SERVER, NULL, "Server Bind Failed!");
        return false;
    }

    if(Proto == 1)
    { //If protocol is specified as TCP, listen on the port
        if ( listen( Socket, 5 ) == -1 )
        {
            CloseSocket();
            Socket = INVALID_SOCKET;
            Log( LOG_PRINT | LOG_CORE_SERVER, NULL, "Server Listen Failed!");
            return false;
        }
    }
    Active    = true; //Set socket as active
    StopMainLoop  = false; //Dont stop the main loop. main loop used for checking for connections
    ConnectedClients = 0; //Number of connected clients, isnt used YET
    Log( LOG_PRINT | LOG_CORE_SERVER, NULL, "Server Start Successful! Listening on port %d",(unsigned short)Port);
    return true;
}






//The CloseSocket function.
//This should be called whenever shutting down the server.
//Closes the socket and runs wsacleanup for windows.
void ServerSocket::CloseSocket( void ) //Close Socket
{
    close(Socket); //Otherwise, close the socket
#ifdef WIN32
    //closesocket(Socket); //Closes Socket
    WSACleanup(); //The Clean up, not required but makes things much faster.
#endif

    Socket = INVALID_SOCKET; //Prepares it just incase the socket is to be started up again. used to catch errors on startup.
    Active = false; //Sets active to false
    Log( LOG_PRINT | LOG_CORE_SERVER, NULL, "Server Closed Successfully!");
}




extern int startmove;
extern int craft_on;

//The RecvLoop Function aka MainLoop
//Used for picking up incomming packets then passing them to the handler
int ServerSocket::RecvLoop(bool Proto)
{
    char Buffer[MAX_BUF]; //leik omfg fixed
#if WIN32

    int clientlen = sizeof(cclient);
#else

    unsigned int clientlen = sizeof(cclient);
#endif
    //WIP!!
    //This loop will check for incomming packets, and pass them off to the handler. The handler will then identify if this is a connection packet
    //and will add the client to a table there. If it isnt a connection packet, it is handled accordingly.
    if(Proto == 1)
    { //Handle later, tcp stuff.
        StopMainLoop = true; //kill the loop, which shuts the server down.
    }
    if(Proto == 0)
    {
        int lasttime = 0;

        fd_set Readable;
        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 1000;

        float x, y, z;
        signed short dir = 0x45;
        x = -178;
        y = -4848;
        z = 28;

        do
        {
            FD_ZERO(&Readable);
            FD_SET(Socket, &Readable);

            select(0, &Readable, NULL, NULL, &tv);

            if (FD_ISSET(Socket, &Readable))
            {
              unsigned short len = 0;
              len = recvfrom(Socket, Buffer, MAX_BUF, 0, (struct sockaddr*)&cclient, &clientlen);
            //insert handlers heree~!
            HandlePacket(Buffer,len);
            //ServerSocket::UDPSendPacket(Buffer, sizeof(Buffer), Port);
            }
            
            int curtime = time(0);
            if (curtime >= lasttime + 1) {
               //printf("%i\n", curtime);
                if (startmove != 0) {
                  x -= startmove * 5.3;
                  recv_pos(this, x, z, y, dir);
                }

                if (craft_on != 0) {
                   --craft_on;
                   if (craft_on % 4 == 0)
                      send_craft_updatetooltime(this);
               
                   if (craft_on == 0)
                      send_craft_finish2(this);
                }

               lasttime = curtime;
            }
           
        }
        while ( !StopMainLoop ); //Keep going unless the Loop told to stop.
    }
    
}

void ServerSocket::HandlePacket(char *pData, unsigned short nLength)
{
    bool comp = false;
    switch(pData[1]) //switch to do packet manip before passing to handlers
    {
        case 3:
        //"Multi-SOE Packet: "
        if(CrcTest(pData,nLength,CrcSeed))
            Decrypt(pData,nLength,CrcSeed);
        if (pData[2] == 'x')
        {
            comp = true;
            pData = Decompress(pData,nLength);
        }
        break;
        case 9:
        //"Data Channel: "
        Decrypt(pData,nLength,CrcSeed);
        if (pData[2] == 'x')
        {
            comp = true;
            pData = Decompress(pData,nLength);
        }
        break;
        case 13:
        //"Fragmented: "
        Decrypt(pData,nLength,CrcSeed);
        if (pData[2] == 'x')
        {
            comp = true;
            pData = Decompress(pData,nLength);
        }
        break;
        case 6:
        //"SOE Ping: "
        Decrypt(pData,nLength,CrcSeed);
        break;
        case 7:
        //"Client Net-Status: "
        Decrypt(pData,nLength,CrcSeed);
        if (pData[2] == 'x')
        {
            comp = true;
            pData = Decompress(pData,nLength);
        }
        break;
        case 21:
        //"Acknowledge: "
        Decrypt(pData,nLength,CrcSeed);
        break;
        case 5:
        //"Disconnect: "
        Decrypt(pData,nLength,CrcSeed);
        break;

        case 17:
        //"Future Packet: "
        Decrypt(pData,nLength,CrcSeed);
        break;
        default:
        //"Unrecorded OP found: "
        break;
    }
    SOEHandler(pData,nLength);
    if (comp)
        delete [] pData;
}

void ServerSocket::SOEHandler(char *pData, unsigned short nLength)
{
    printf("packet red [%x]\n",pData[1]);

    switch(pData[1])
    {
        case 3:
        //"Multi-SOE Packet: "
        pData+=2;
        for(short i =2;i < nLength-4;i++)
        {
            unsigned short segment_size = 0;
            if((unsigned char)pData[0] == 0xFF)
            {
                segment_size += 255;
                pData++;
                i++;
                unsigned char counter = (unsigned char)*pData;
                for(short c = 0;c < counter;c++)
                pData++;
                i++;
                segment_size += (unsigned char)*pData;
            }
            else
                segment_size += (unsigned char)*pData;
            pData++;
            i++;
            SOEHandler(pData,segment_size);
            i+=segment_size;
            pData+=segment_size;
        }
        break;

        case 9:
        //"Data Channel: "
        {
        pData+=2;
        oclient.client_sequence = *(unsigned short*)(pData);
        
        
        pData+=2;
        if(pData[0] == 0x00 && pData[1] == 0x19)
        {
        pData+=2;
        for(short i =0;i < nLength-6;i++)
        {
            unsigned short segment_size = 0;
            if((unsigned char)pData[0] == 0xFF)
            {
                segment_size += 255;
                pData++;
                i++;
                unsigned char counter = *(unsigned char*)pData;
                for(short c = 0;c < counter;c++)
                pData+=1;
                i++;
                segment_size += (unsigned char)*pData;
            }
            else
            {
            segment_size += *(unsigned char*)pData;
            }
            pData++;
            i++;
            unsigned int *opcode = (unsigned int*)(pData+2);
            switch(*opcode)
            {
         
            case 0x80CE5E46: //46 5E CE 80 big packet for movement,chat,escape,waypoints blah blah blah
            send_ack_ok(this,oclient.client_sequence);
            //printf("ACKOK!!!1!!\n\n");
            break;
            
            default:
            send_ack(this, oclient.client_sequence);
            break;
            }
            
            SWGHandler(pData,segment_size);
            i+=segment_size;
            pData+=segment_size;
        }
        }
        else
        {
        unsigned short segment_size = nLength-4;
        unsigned int *opcode = (unsigned int*)(pData+2);
        switch(*opcode)
        {
         
        case 0x80CE5E46: //46 5E CE 80 big packet for movement,chat,escape,waypoints blah blah blah
        send_ack_ok(this,oclient.client_sequence);
        printf("ACKOK!!!1!!\n\n");
        break;
        
        default:
        send_ack(this, oclient.client_sequence);
        break;
        }
        
        SWGHandler(pData,segment_size);
        }
        }
        break;
        case 13:
        //"Fragmented: "


        break;
        case 6:
        //"SOE Ping: "
        ping_reply(this);
        break;
        case 7:
        //"Client Net-Status: "
        { //dunno why, but it needs these cause declerations in switchs = evil
        unsigned short tick  = *(unsigned short*)(pData+2);
        send_netstat(this,tick);
        }
        break;
        case 5:
        //"Disconnect: "
        oclient.server_sequence = 0;
        oclient.client_sequence = 0;
        oclient.seq_recv = 0;
        break;
        case 1:
        //"Session Request: "
        {
         oclient.connection_id = *(unsigned int*)(pData+6);
         CrcSeed = oclient.CrcSeed;
         send_sesresp(this);
        }
        break;
        case 17:
        //"Future Packet: "
        break;
        case 21:
        //"Acknowledge: "
        {
        unsigned short seq = *(unsigned short*)(pData+2);
        oclient.seq_recv = seq;
        //you can add a check here *shrug*
        //if(oclient.seq_recv == oclient.server_sequence)
        //its ok, if not, re-request packet?
        pData+=2;
        oclient.client_sequence = *(unsigned short*)(pData);
        }
        break;
        case 29:
        //"Resend Client Info: "
        break;
        default:
        //"Unrecorded OP found: "
        pData+=2;
        nLength-=4;
        SWGHandler(pData,nLength);
        break;
    }
}


void ServerSocket::SWGHandler(char *pData,unsigned short nLength)
{
 unsigned short *group = (unsigned short*)(pData);
 ntohs(*group);
 unsigned int *opcode = (unsigned int*)(pData+2);

 switch(*group)
 {
  case 1:
  switch(*opcode)
      {
       case 0x43FD1C22:
       recv_load_done(this);
       break;
       case 0x4C3D2CFA: //some opcode sent after terrain is done loading. Is OK'd..
       send_OK_packet(this);
       break;
          default:
          printf("unknown [1] opcode %x\n",*opcode);
          break;
      }
  break;

  case 2:
  switch(*opcode)
       {
          case 0xB5098D76: //76 8D 09 B5 (zone insert request w/ character ID)
          if (spawny.initalized == false) {
            spawny.x = -178;
            spawny.y = -4848;
            spawny.z = 0;
            spawny.location = "corellia";
            spawny.initalized = true;
          }
          recv_charID(this,spawny);
          break;

          case 0xD6D1B6D1: //D1 B6 D1 D6 (char creation name request w/ race IFF)
          recv_char_iff(this,pData,nLength);
          break;

          case 0xCA88FBAD: //client ready string
          send_OK_packet(this);
          break;
          default:
          printf("unknown [2] opcode %x\n",*opcode);
          break;
       }
  break;


  case 3:
  switch(*opcode)
       {//26 92 89 d5 (session + version from client)
          case 0xD5899226:
          send_OK_packet(this);
          recv_session_key(this);
          break;
          case 0x7CA18726:
                  send_ack_ok(this,oclient.client_sequence);
                  //send_OK_packet(this);

                  send_loot_open(this);
          break;
          default:
          printf("unknown [3] opcode %x\n",*opcode);
          break;
       }
  break;


  case 4:
  break;
  case 5:

  printf("with opcode %x\n",*opcode);
        
  switch(*opcode)
    {
      case 0x84BB21F7:              // F7 21 BB 84  - TELL
           recv_tell(this, pData);
           break;
         
      case 0x80CE5E46: //46 5E CE 80 big packet for movement,chat,escape,waypoints blah blah blah
           unsigned int *int3 = (unsigned int*)(pData+30);
           unsigned int *int4 = (unsigned int*)(pData+10);

           unsigned long long *resID;
           unsigned int *slot, *slot2;
           unsigned char *scount;
           unsigned int unicodeLength;
           wchar_t *unicode;
           
           printf("with id %x\n",*int4);
           switch (*int4) 
           {
              case 0x146:
                   send_ack_ok(this,oclient.client_sequence);
                         
                   send_radial_confirm(this, pData, nLength);
                   break;
              case 0x126:
                   send_ack_ok(this,oclient.client_sequence);
                   break;
              case 0x107:
                   resID = (unsigned long long *)(pData+26);
                   slot = (unsigned int *)(pData+34);
                   slot2 = (unsigned int *)(pData+38);
                   scount = (unsigned char *)(pData+42);
                   //if (resID == 0x116876a945)
                   printf("resource slot [%x, %x, %x, %x]\n", (unsigned int)*resID, *slot, *slot2, *scount);
                   //hex_print(pData, nLength);
                   send_insert_resource(this, resID, slot, scount);
                   break;
              case 0x106:
                   send_ack_ok(this,oclient.client_sequence);

                   hex_print(pData, nLength);

                   send_craft_experiment(this);
                   break;
              case 0x15a:
                   send_ack_ok(this,oclient.client_sequence);

                   send_craft_createobj(this);
                   break;

              case 0x116:
                   switch(*int3)
                   {
                     case 0x7C8D63D4: //D4 63 8D 7C - spatial chat
                          recv_chat(this, pData, nLength);
                          break;
           
                     case 0x5C186E02: //0x02 0x6e 0x18 0x5c - mission terminal open
                          break;
           
                     case 0x5C186E05: //0x05 0x6e 0x18 0x5c - mission terminal refresh
                          break;

                     case 0xB719FA26:      // 26 FA 19 B7 - /sit
                          recv_cmd_sit(this);
                          break;

                     case 0xA8A25C79:      // 79 5C A2 A8 - /stand
                          recv_cmd_stand(this);
                          break;

                     case 0xBD8D02AF: // AF 02 8D BD - /prone
                          recv_cmd_prone(this);
                          break;

                     case 0x01B48B26: // 26 8B B4 01 - /kneel
                          recv_cmd_kneel(this);
                          break;

                     case 0x32CF1BEE: //EE 1B CF 32 - emotes
                          recv_emote(this, pData);
                          break;
           
                     case 0xA8FEF90A:      // 0A F9 FE A8 - ATTACK!
                          recv_attack(this, pData);
                          break;
           
                     case 0x4178FD6A:              //6A FD 78 41 - PEACE!
                          recv_peace(this, pData);
                          break;
           
                     case 0xFC3D1CB2:        //B2 1C 3D FC - burst run
                          recv_burstrun(this,pData);
                          break;

                     case 0x82f75977:
                          send_ack_ok(this,oclient.client_sequence);

                          send_loot_pearl(this);
                          break;

                     case 0x94ac516:
                          send_ack_ok(this,oclient.client_sequence);

                          send_craft(this);
                          break;

                     case 0x83250e2a:
                          send_ack_ok(this,oclient.client_sequence);

                          printf("huh\n");
                          break;

                     case 0x89242e02:
                          send_ack_ok(this,oclient.client_sequence);

                          send_craft_stage1(this);
                          send_craft_updateschems(this);

                          break;

                     case 0x6ad8ed4d:
                          send_ack_ok(this,oclient.client_sequence);

                          unicodeLength = *(unsigned int *)(pData+42);
                          /**unicode = new unicode[unicodeLength+1];
                          unicode[unicodeLength] = 0;*/

                          hex_print(pData, nLength);
                          send_craft_assemble(this);
                          break;

                     case 0xd61ff415:
                          send_ack_ok(this,oclient.client_sequence);

                          send_craft_finish(this);
                          break;

                     // click on res
                     case 0x164550ef:
                          send_ack_ok(this,oclient.client_sequence);

                          printf("attr update\n");
                          //hex_print(pData, nLength);
                          //send_insert_updateres(this);
                          break;
           
                     case 0x00000000: //00 00 00 00 - position
                          if (((*(unsigned short*)(pData+6)) == 0x23) && ((*(unsigned short*)(pData+10)) == 0x71)) {
                          //hex_print(pData, nLength);
                          //recv_pos(this,*(float*)(pData+46),*(float*)(pData+50),*(float*)(pData+54),*(signed short*)(pData+44));
                          }
                          break;

                     default:
                          printf("unknown with id %x\n",*int3);
                          hex_print(pData, nLength);
                          break;
                   }
                   break;
              default:
                   printf("unknown header [%x]\n",*int4);
                   hex_print(pData, nLength);
                   break;
           }
           break;

      /*default:
           printf("unknown opcode %x\n",*opcode);
           break;*/
    }
  break;

  case 6:
  break;
  case 7:
  break;
  case 8:
  break;
  case 9:
  break;
  case 10:
  break;
  case 11:
  break;
  case 12:
  switch(*opcode)
       { //74 30 7F B9 Character create: detailed char info
          case 0xB97F3074:
          send_OK_packet(this);
          send_assign_char_id(this);
          break;
          default:
          printf("unknown [12] opcode %x\n",*opcode);
          break;
       }
  break;
  case 13:
  break;
  case 14:
  break;
  case 15:
  break;
 }
}

void ServerSocket::SendSWG(char *pData,unsigned short nLength, bool Enc,bool Comp,bool CRC)
{
    if(Comp)
    {
        pData = Compress(pData,nLength);
    }
    if(Enc)
    {
        Encrypt(pData,nLength,CrcSeed);
    }
    if(CRC)
    {
    AppendCRC(pData,nLength,CrcSeed);
    }
    UDPSendPacket(pData,nLength);
    if(Comp)
    {
        delete [] pData;
    }
}


//The UDPSendPacket Function
//Used just for sending a udp packet
void ServerSocket::UDPSendPacket(char* Data, unsigned short len)
{
    //Example of usage: ServerSocket::UDPSendPacket(Buffer, 2, Port);
#if WIN32
    int clientlen = sizeof(cclient);
#else

    unsigned int clientlen = sizeof(cclient);
#endif

    sendto(Socket, Data, len, 0, (struct sockaddr*)&cclient,clientlen);
}

void ServerSocket::hex_print(char* data, int length)
{
for(int i = 0; i < length; i++)
{
printf("0x%02x ",(unsigned char)*(data+i));
}
printf("\n");
}

void ServerSocket::ascii_to_unicode(wchar_t *destination, char *source, int length)
{
     for(int i=0; i < length; i++)  destination[i] = source[i];
}

void ServerSocket::unicode_to_ascii(char *destination, wchar_t *source, int length)
{
     for(int i=0; i < length; i++)  destination[i] = source[i];
}
