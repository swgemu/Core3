//
//CoreSocket.h
//(C) SWGEmu 2006
//
//Header file for the serversocket & main.cpp source files.
//

#ifndef SERVERSOCKET_H
#define SERVERSOCKET_H

#include "log.h"
#include "ConfigFile.h"

/*#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>*/
#define MAX_BUF 512

#ifdef WIN32 //Windows Socket
//#include <windows.h>
#include <winsock2.h>
#define close closesocket

#else //BSD Socket header files
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <string.h>
#define SOCKET int
#define INVALID_SOCKET -1
#endif


typedef struct client_object
{
unsigned short server_sequence;
unsigned short client_sequence;
unsigned short seq_recv;
const static unsigned int CrcSeed = 0xDEADBABE;
unsigned int connection_id;
unsigned int station_id;
char char_name_first[17];
char char_name_last[17];
char password[17];
char station_name[17];
};

//The ServerSocket Class.
//Used for all the Server's Socket Functions.
class ServerSocket// : public CoreSocket
{
public:
	ServerSocket();
	~ServerSocket();

	SOCKET			Socket;				//Socket
	bool			Active;				//Server Active
	#ifdef WIN32
    bool InitSocket (void);
    #endif
    void CloseSocket(void);
	bool StartServer		(unsigned short Port, bool Proto);	//Server Start function
	void ServerMainLoop		( void );					// Mainloop
	int RecvLoop(bool Proto);
	void UDPSendPacket (char* Data, unsigned short len);
	struct sockaddr_in ain, cclient;
	void HandlePacket(char *pData, unsigned short nLength);
	void SOEHandler(char *pData, unsigned short nLength);
	void SWGHandler(char *pData, unsigned short nLength);
    void SendSWG(char *pData,unsigned short nLength,bool Enc=false,bool Comp=false,bool CRC=true);
    void ascii_to_unicode(wchar_t *destination, char *source, int length);
    void unicode_to_ascii(char *destination, wchar_t *source, int length);
    void ServerSocket::hex_print(char* data, int length);
protected:
    bool				StopMainLoop;					// Set to TRUE to leave servers loop
	unsigned			ConnectedClients; 	// Count of the connected clients
	unsigned int CrcSeed;		
	int ret; //Used for blocking modes
	//For setting the blocking mode.
	#if WIN32
	unsigned long mode;
	#else
	long mode;
	#endif
};

#endif

